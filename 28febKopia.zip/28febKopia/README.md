{Red Room!}

Finn ut av:

=> Lese boks A-E, 1-3
    if/else eller finns det ett lättare sätt??

=> Åpne og lukke a´la Ruter

=> Farge over valgt + Css for att klikke "igjenom"

    pointer-events: none;
    background: url('your_transparent.png');

=> "Dutte ned" fra boks til list Url#
    Kan va till hjälp
    http://stackoverflow.com/questions/18071046/smooth-scroll-to-specific-div-on-click
    

=> hålla bokser på plass i mobil.

=> mindre header (for mobil hvertfall), gjøre sticky og legge navigasjon mellom sessions her